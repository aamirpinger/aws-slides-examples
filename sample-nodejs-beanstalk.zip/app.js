const express = require('express')
const app = express()

const port = process.env.PORT || 8080;

app.get('/', function(req, res){
 res.send("<h1>Congratulation, you have just learned how to make your application up and running using AWS Beanstalk!</h1><br><br><a href='/helloworld'>Click here to change the page</a>")
})

app.get('/helloworld', function(req, res){
 res.send({
	message: "Hello World from Beanstalk App"
	})
})

app.listen(port, () => {
   console.log("server is up, check http://localhost:" + port)
})

